package com.example.wifi_info.algorithm;

import java.util.List;

import com.example.wifi_info.tools.Infor;
import com.example.wifi_info.tools.Point;
import com.example.wifi_info.tools.Position;

/**
 * 
 * @author nupt
 *
 */
public class Algorithm {

	/**
	 * ƥ���㷨
	 * 
	 * @param points
	 * @param p
	 * @return
	 */
	public Position method(List<Point> points, Point p) {

		return method(points, p.getInfors());

	}

	/**
	 * ƥ���㷨
	 * 
	 * @param points
	 * @param infors
	 * @return
	 */
	public Position method(List<Point> points, List<Infor> infors) {
		// TODO Auto-generated method stub

		// ��ʼ�����ж�
		if (initialCondition(points, infors))
			System.out.println("�����ʼ������");
		else {
			System.out.println("�������ʼ������");
			return null;
		}

		double[][] datas = datasToArr(points);// pointsת��Ϊ��ά����
		// printѵ������
		print(datas, "ѵ������");

		double[] test = testToArr(infors); // inforsת��Ϊһά����
		// print��������
		print(test, "��������");

		double[] distance = getDistance(datas, test);//  ����datas[i]��test��ŷʽ����

		while (true) {
			// printlnŷʽ����
			println(distance, "ŷʽ����");

			int[] order = getOrder(distance);// ��С���������,order[0]��ֵΪ��Сŷʽ�������ڽǱ�
			// println��С˳��
			println(order, "distance��С�����index");

			int k = kValue(distance);// ����ŷʽ����ȷ��kֵ
			System.out.println("k = " + k);

			int[] index = getIndex(order, k);// ��ȡk���Ǳ�
			// println index
			println(index, "index");

			Position[] pos = getPos(points, index);// K������
			// printlnǰk������
			for (Position p : pos)
				System.out.print(p);

			Position mathCentre = getMathCentre(pos, pos.length);// K������ļ������ĵ�
			// println�������ĵ�
			System.out.println("�������ĵ�" + mathCentre);

			double[] mathCentreDis = getMathCentreDis(pos, mathCentre);// k�������뼸�����ĵ����
			// println k�������뼸�����ĵ����
			println(mathCentreDis, "k�������뼸�����ĵ����");

			int maxIndex = getMaxIndex(mathCentreDis);// k�������о༸�����ĵ���ԶԪ�ؽǱ�
			// ptintln maxIndex
			System.out.println("maxIndex = " + maxIndex);

			if (mathCentreDis[maxIndex] > 12) {
				distance[index[maxIndex]] = Double.MAX_VALUE;// ����maxIndex��ָ���Position
				continue;
			}

			double[] weight = getWeight(distance, index, Kinds.WKNN);// Ȩֵ
			// printlnȨֵ
			println(weight, "Ȩ��");

			Position centre = calculate(pos, weight);// ���ĵ�

			return centre;
		}

	}

	/**
	 * ����arr[]��Ԫ�����ֵ���ڽǱ�
	 * 
	 * @param mathCentreDis
	 * @return
	 */
	private int getMaxIndex(double[] arr) {
		// TODO Auto-generated method stub
		int length = arr.length;
		int index = -1;

		double max = 0;

		for (int i = 0; i < length; i++) {
			if (arr[i] > max) {
				max = arr[i];
				index = i;
			}

		}

		return index;
	}

	/**
	 * ����������뼸�����ĵ����
	 * 
	 * @param pos
	 * @param mathCentre
	 * @return
	 */
	private double[] getMathCentreDis(Position[] pos, Position mathCentre) {
		// TODO Auto-generated method stub
		int length = pos.length;
		double[] arr = new double[length];

		for (int i = 0; i < length; i++)
			arr[i] = Math.sqrt((pos[i].getPosX() - mathCentre.getPosX())
					* (pos[i].getPosX() - mathCentre.getPosX())
					+ (pos[i].getPosY() - mathCentre.getPosY())
					* (pos[i].getPosY() - mathCentre.getPosY()));

		return arr;
	}

	/**
	 * ���㼸�����ĵ�
	 * 
	 * @param pos
	 * @param length
	 * @return
	 */
	private Position getMathCentre(Position[] pos, int length) {
		// TODO Auto-generated method stub
		double posX = 0, posY = 0;
		for (Position p : pos) {
			posX += p.getPosX();
			posY += p.getPosY();
		}

		return new Position(posX * 1.0 / length, posY * 1.0 / length);
	}

	/**
	 * ����(x,y)
	 * 
	 * @param pos
	 * @param weight
	 * @return
	 */
	private Position calculate(Position[] pos, double[] weight) {
		// TODO Auto-generated method stub

		double x = 0, y = 0;
		for (int i = 0; i < pos.length; i++) {
			x += pos[i].getPosX() * weight[i];
			y += pos[i].getPosY() * weight[i];
		}

		return new Position(x, y);
	}

	/**
	 * �����Ȩֵ��KNNȨ��Ϊ1��WKNNȨ��Ϊdistance�ĵ���֮��ռ�ȡ�Ĭ��KNN
	 * 
	 * @param distance
	 * @param index
	 * @param knn
	 * @param str
	 * @return
	 */
	private double[] getWeight(double[] distance, int[] index, Kinds kind) {
		// TODO Auto-generated method stub
		int length = index.length;
		// ��¡һ��double[] distance
		double[] clone = distance.clone();

		double[] res = new double[length];
		switch (kind) {
		case KNN:
			for (int i = 0; i < length; i++)
				res[i] = 1 / (length * 1.0);
			break;
		case WKNN: {
			double sum = 0;
			for (int i = 0; i < length; i++) {
				clone[index[i]] = 1 / (clone[index[i]] + 0.01);
				sum += clone[index[i]];
			}

			for (int i = 0; i < length; i++) {
				res[i] = clone[index[i]] / sum;
			}
			break;
		}

		default:
			for (int i = 0; i < length; i++)
				res[i] = 1 / (length * 1.0);
			break;
		}

		return res;
	}

	/**
	 * ��ȡǰK������
	 * 
	 * @param points
	 * @param index
	 * @return
	 */
	private Position[] getPos(List<Point> points, int[] index) {
		// TODO Auto-generated method stub
		int length = index.length;

		Position[] pos = new Position[length];
		for (int i = 0; i < length; i++) {
			pos[i] = points.get(index[i]).getPos();
		}

		return pos;
	}

	/**
	 * ��ʼ������List<Infor> infors �е�BSSID������λ����ͬ
	 * 
	 * @param datas
	 * @param test
	 * @return
	 */
	private boolean initialCondition(List<Point> datas, List<Infor> test) {
		if (datas == null || test == null)
			return false;

		List<Infor> infData = datas.get(0).getInfors();

		// Ҫ��BSSID������ͬ
		if (infData.size() != test.size())
			return false;

		int size = test.size();

		// Ҫ��BSSID˳����ͬ
		for (int i = 0; i < size; i++) {

			String str1 = infData.get(i).getBssid();
			String str2 = test.get(i).getBssid();

			if (!str1.equals(str2))
				return false;
		}

		return true;
	}

	/**
	 * eleDatasת����
	 * 
	 * @param eleDatas
	 * @return
	 */
	private double[][] datasToArr(List<Point> points) {
		// TODO Auto-generated method stub
		int pointsSize = points.size();
		int inforsSize = points.get(0).getInfors().size();

		double[][] datas = new double[pointsSize][inforsSize];

		for (int j = 0; j < pointsSize; j++) {
			List<Infor> infData = points.get(j).getInfors();
			for (int i = 0; i < infData.size(); i++) {
				datas[j][i] = infData.get(i).getLevel();
			}
		}
		return datas;
	}

	/**
	 * eleTestת����
	 * 
	 * @param eleTest
	 * @return
	 */
	private double[] testToArr(List<Infor> infors) {
		// TODO Auto-generated method stub
		int size = infors.size();
		double[] test = new double[size];
		for (int i = 0; i < size; i++) {
			test[i] = infors.get(i).getLevel();
		}
		return test;
	}

	/**
	 * 
	 * ŷʽ����
	 * 
	 * @param datas
	 * @param test
	 * @return
	 */
	private double[] getDistance(double[][] datas, double[] test) {
		// TODO Auto-generated method stub
		int length = datas.length;

		double[] res = new double[length];
		for (int i = 0; i < length; i++) {
			res[i] = getDistance(datas[i], test);
		}
		return res;
	}

	/**
	 * ŷʽ����
	 * 
	 * @param arr1
	 * @param arr2
	 * @return
	 */
	private double getDistance(double[] data, double[] test) {

		// ���arr1��arr2�ĳ��Ȳ�ͬ������ֵΪ��
		if (data.length != test.length)
			return -1.0;

		double result = 0;

		for (int i = 0; i < data.length; i++) {
			double temp = data[i] - test[i];
			temp *= temp;
			result += temp;
		}

		return Math.sqrt(result);

	}

	/**
	 * ���ı�Ԫ��λ�ã���С�����˳��ָ����������λ�á� a[0]=5��ʾŷʽ������Сֵ�ڽǱ�Ϊ5��
	 * 
	 * @param arr
	 * @return
	 */
	private int[] getOrder(double[] arr) {
		int length = arr.length;
		// ��¡һ������
		double[] clone = arr.clone();

		int[] res = new int[length];

		for (int i = 0; i < length; i++) {

			double min = clone[0];
			res[i] = 0;

			for (int j = 1; j < length; j++) {

				if (clone[j] < Double.MAX_VALUE && clone[j] < min) {
					min = clone[j];
					res[i] = j;
				}

			}

			clone[res[i]] = Double.MAX_VALUE;

		}

		return res;
	}

	/**
	 * ����ŷʽ���룬ȷ��Kֵ
	 */

	private int kValue(double[] distance) {
		// TODO Auto-generated method stub
		int length = distance.length;
		int[] order = getOrder(distance);

		try {

			int min = 3, max = length;

			return 6;

		} catch (Exception e) {
			// TODO: handle exception
			return 1;
		}

	}

	/**
	 * ǰK���Ǳ�
	 * 
	 * @param order
	 * @param k
	 * @return
	 */
	private int[] getIndex(int[] order, int k) {
		// TODO Auto-generated method stub
		int[] res = new int[k];
		for (int i = 0; i < k; i++) {
			res[i] = order[i];
		}
		return res;
	}

	/**
	 * 
	 * @author nupt
	 *
	 */
	private enum Kinds {
		KNN, WKNN
	}

	private void print(double[] arr) {
		// TODO Auto-generated method stub
		int length = arr.length;
		for (int i = 0; i < length; i++)
			System.out.print(arr[i] + "\t");
		System.out.println();
	}

	private void print(double[] arr, String str) {
		// TODO Auto-generated method stub
		System.out.println(str);
		print(arr);
	}

	private void print(double[][] arr, String str) {
		// TODO Auto-generated method stub
		System.out.println(str);
		int length = arr.length;
		for (int i = 0; i < length; i++)
			print(arr[i]);
	}

	private void println(double[] arr, String str) {
		// TODO Auto-generated method stub
		System.out.println(str);
		int length = arr.length;
		for (int i = 0; i < length; i++)
			System.out.println("[" + i + "]=" + arr[i]);
	}

	private void println(int[] arr, String str) {
		// TODO Auto-generated method stub
		System.out.println(str);
		int length = arr.length;
		for (int i = 0; i < length; i++)
			System.out.println("[" + i + "]=" + arr[i]);
	}

}
