package com.example.wifi_info.database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.example.wifi_info.tools.Infor;
import com.example.wifi_info.tools.Item;
import com.example.wifi_info.tools.Point;
import com.example.wifi_info.tools.Position;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class WifiDao {
	private WifiSQLiteOpenHelper helper;

	public WifiDao(Context context) {
		helper = new WifiSQLiteOpenHelper(context);
	}

	/**
	 * ��������
	 * 
	 * @param ssid
	 * @param bssid
	 * @param level
	 * @param posX
	 * @param posY
	 * @param frequency
	 * @param timestamp
	 * @return
	 */
	public long add(String ssid, String bssid, int level, double posX, double posY, int frequency, String timestamp) {
		SQLiteDatabase db = helper.getWritableDatabase();
		// db.execSQL("insert into wifi (ap_name, ap_level number) values
		// (?,?)");
		ContentValues values = new ContentValues();

		values.put("ssid", ssid);
		values.put("bssid", bssid);
		values.put("level", level);
		values.put("posX", posX);
		values.put("posY", posY);
		values.put("frequency", frequency);
		values.put("timestamp", timestamp);

		long id = db.insert("wifi", null, values);

		db.close();

		return id;
	}

	public long add(String ssid, String bssid, int level, double posX, double posY, double posZ, int frequency,
			String timestamp) {
		SQLiteDatabase db = helper.getWritableDatabase();
		// db.execSQL("insert into wifi (ap_name, ap_level number) values
		// (?,?)");
		ContentValues values = new ContentValues();

		values.put("ssid", ssid);
		values.put("bssid", bssid);
		values.put("level", level);
		values.put("posX", posX);
		values.put("posY", posY);
		values.put("posZ", posZ);
		values.put("frequency", frequency);
		values.put("timestamp", timestamp);

		long id = db.insert("wifi", null, values);

		db.close();

		return id;
	}

	/**
	 * ��˹����
	 * 
	 * @param ssid
	 * @param bssid
	 * @param level
	 * @param posX
	 * @param posY
	 * @param frequency
	 * @param timestamp
	 * @return
	 */

	public long addGauss(String ssid, String bssid, double level, double posX, double posY, double posZ,int frequency,
			String timestamp) {
		SQLiteDatabase db = helper.getWritableDatabase();

		ContentValues values = new ContentValues();

		values.put("ssid", ssid);
		values.put("bssid", bssid);
		values.put("level", level);
		values.put("posX", posX);
		values.put("posY", posY);
		values.put("posZ", posZ);
		values.put("frequency", frequency);
		values.put("timestamp", timestamp);

		long id = db.insert("wifi_gauss", null, values);

		db.close();

		return id;
	}

	/**
	 * ��levelƽ��ֵ
	 */
	public boolean avg() {
		SQLiteDatabase db = helper.getReadableDatabase();
		db.execSQL("delete from wifi_avg;");
		db.execSQL("insert into wifi_avg" + "(ssid,bssid,level,posX,posY,posZ)"
				+ " select ssid,bssid,round(avg(level),2) as level,posX,posY,posZ"
				+ " from wifi group by posX,posY,posZ,bssid;");

		db.close();
		return true;
	}

	/**
	 * 
	 * @param sql
	 *            bssid0\t\tbssid1\t\t...bssidn\t\t
	 * 
	 * @return ������ǿAPѡ���ĵ㼯
	 */
	public List<Point> returnTempTable(String sql) {

		SQLiteDatabase db = helper.getWritableDatabase();

		StringBuffer sb = new StringBuffer();
		sb.append("posX\t\tposY\t\tposX\t\t");
		sb.append(sql.trim());

		String[] columns = sb.toString().split("\t\t");

		// ɾ����ʱ��
		try {

			db.execSQL("drop table temp;\n");

		} catch (Exception e) {
			// TODO: handle exception
		}

		// ������ʱ��temp
		sb.delete(0, sb.length());
		sb.append("create table temp(id integer primary key autoincrement, posX real, posY real,posZ real");
		for (int i = 3; i < columns.length; i++) {
			sb.append(", ");
			sb.append("'" + columns[i] + "'");
			sb.append(" real");
		}
		sb.append(");");
		db.execSQL(sb.toString());

		// ��������
		sb.delete(0, sb.length());
		sb.append("insert into temp(posX, posY,posZ");
		for (int i = 3; i < columns.length; i++) {
			sb.append(",");
			sb.append("'" + columns[i] + "'");
		}
		sb.append(")\n");
		sb.append("select  posX, posY,posZ");
		for (int i = 3; i < columns.length; i++) {
			sb.append(",");
			sb.append("avg(case bssid when ");
			sb.append("'" + columns[i] + "'");
			sb.append(" then level end) ");
			sb.append("'" + columns[i] + "'");
		}
		sb.append(" from wifi_gauss group by posX, posY,posZ;");

		// System.out.println(sb.toString());
		db.execSQL(sb.toString().trim());

		// ���ص���ʱ����
		List<Point> points = new ArrayList<Point>();

		Cursor cursor = db.rawQuery("select * from temp", null);

		while (cursor.moveToNext()) {

			double posX = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posX")));
			double posY = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posY")));
			double posZ = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posZ")));

			String[] bssids = new String[columns.length - 2];
			double[] levels = new double[columns.length - 2];

			for (int i = 0; i < columns.length - 2; i++) {

				try {

					bssids[i] = cursor.getColumnName(i + 3);
					levels[i] = Double.parseDouble(cursor.getString(cursor.getColumnIndex(columns[i + 2])));

				} catch (Exception e) {
					// TODO: handle exception
					// levelsΪnullʱ��ֵ-100.0
					levels[i] = -100.0;
				}

			}

			List<Infor> li = new ArrayList<Infor>();
			for (int i = 0; i < bssids.length; i++)
				li.add(new Infor(bssids[i], levels[i]));

			Point p = new Point(new Position(posX, posY, posZ), li);
			points.add(p);
		}

		cursor.close();
		db.close();

		return points;

	}

	/**
	 * ɾ��
	 * 
	 * @param ap_ssid
	 * @return
	 */
	public int delete(String ap_ssid) {
		SQLiteDatabase db = helper.getWritableDatabase();
		// db.execSQL("delete from person where name=?", new Object[]{name});
		int result = db.delete("WIFI", "ap_ssid=?", new String[] { ap_ssid });
		db.close();
		return result;
	}

	/**
	 * ����δƽ��ǰȫ������
	 * 
	 * @return
	 */
	public List<Item> getAllItem() {

		SQLiteDatabase db = helper.getWritableDatabase();
		Cursor cursor = db.rawQuery("select * from wifi", null);

		List<Item> list_item = new LinkedList<Item>();

		while (cursor.moveToNext()) {

			double posX = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posX")));
			double posY = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posY")));
			double posZ = Double.parseDouble(cursor.getString(cursor.getColumnIndex("posZ")));

			Position pos = new Position(posX, posY,posZ);

			String bssid = cursor.getString(cursor.getColumnIndex("bssid"));

			double level = Double.parseDouble(cursor.getString(cursor.getColumnIndex("level")));

			list_item.add(new Item(pos, bssid, level));

		}

		db.close();
		return list_item;

	}

}
